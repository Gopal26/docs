package com.cognizant.entity;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "USER_DETAILS")
public class UserDetails {

	@Override
	public String toString() {
		return "UserDetails [accountNumber=" + accountNumber + ", accountType=" + accountType + ", acountHolderName="
				+ acountHolderName + ", accountBalance=" + accountBalance  + ", tdDetails=" + tdDetails + "]";
	}

	@Id
	@Column(name = "ACCOUNT_NUMBER")
	long accountNumber;

	@Column(name = "ACCOUNT_TYPE", length = 20)
	// @Type(type="text")
	String accountType;

	@Column(name = "ACCOUNT_HOLDER_NAME", length = 20)
	// @Type(type="text")
	String acountHolderName;

	@Column(name = "ACCOUNT_BALANCE", length = 20)
	long accountBalance;


	public UserDetails() {
	}

	public UserDetails(long accountNumber, String accountType, String acountHolderName, long accountBalance) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.acountHolderName = acountHolderName;
		this.accountBalance = accountBalance;
	}

	/*
	 * @Override public String toString() { return "UserDetails [accountNumber="
	 * + accountNumber + ", accountType=" + accountType + ", acountHolderName="
	 * + acountHolderName + ", accountBalance=" + accountBalance + ", homeLoan="
	 * + homeLoan + ", eduLoan=" + eduLoan + ", tdDetails=" + tdDetails + "]"; }
	 */
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "ACCOUNT_NUMBER")
	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAcountHolderName() {
		return acountHolderName;
	}

	public void setAcountHolderName(String acountHolderName) {
		this.acountHolderName = acountHolderName;
	}

	public long getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(long newBalance) {
		this.accountBalance = newBalance;
	}

	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<EducationLoan> eduLoan;

	public List<EducationLoan> getEduLoan() {
		return eduLoan;
	}

	public void setEduLoan(List<EducationLoan> eduLoan) {
		this.eduLoan = eduLoan;
	}

	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL,fetch=FetchType.LAZY)
	private List<TransactionDetails> tdDetails;

	public List<TransactionDetails> getTdDetails() {
		return tdDetails;
	}

	public void setTdDetails(List<TransactionDetails> tdDetails) {
		this.tdDetails = tdDetails;
	}


}
