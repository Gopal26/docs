package com.cognizant.dao;

public class ApplicationDAO{
	// Add appropriate annotations and code wherever required
}
