package com.cognizant.controller;


public class ApplicationController {

	// Add appropriate annotations and code wherever required



}
