package com.cognizant.exception;

public class EducationLoanException extends RuntimeException {
	public EducationLoanException(String s) {
		super(s);
	}
}
