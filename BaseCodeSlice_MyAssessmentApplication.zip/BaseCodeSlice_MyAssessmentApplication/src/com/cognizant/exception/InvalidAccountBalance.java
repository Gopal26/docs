package com.cognizant.exception;

public class InvalidAccountBalance extends RuntimeException {

	public InvalidAccountBalance(String s) {
		super(s);
	}

}
