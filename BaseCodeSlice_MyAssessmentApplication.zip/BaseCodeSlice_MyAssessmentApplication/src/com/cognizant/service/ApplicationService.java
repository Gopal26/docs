package com.cognizant.service;

public class ApplicationService  {
	// Add appropriate annotations and code wherever required
}
